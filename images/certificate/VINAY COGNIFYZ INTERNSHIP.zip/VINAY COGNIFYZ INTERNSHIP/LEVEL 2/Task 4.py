def fib_list(n):
  if n < 0:
    print("Enter a non-negative integer")
    return None
  elif n == 0:
    return []
  elif n == 1:
    return [0]
  else:
    a, b = 0, 1
    fib_sequence = [a, b]
    for num in range(2, n):
      c = a + b
      fib_sequence.append(c)
      a, b = b, c
    return fib_sequence
n=int(input("Enter the number of terms.Ensure that it is a non-negative integer:"))
lst=fib_list(n)
print("The fibonacci sequence is:",lst)
