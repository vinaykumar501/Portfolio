import random
def guess_the_number():
    num = random.randint(1, 100)
    while True:
        guess=int(input("Guess a number between 1 and 100: "))
        if guess > num:
            print("The number you guessed is too high.Try again")
        elif guess < num:
            print("The number you guessed is too low.Try again")
        else:
            print(f"You guessed the number {num} perfectly!")
            break
guess_the_number()
