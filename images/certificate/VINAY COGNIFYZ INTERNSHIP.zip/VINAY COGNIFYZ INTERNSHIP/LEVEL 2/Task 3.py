import re
def password_strength(password):
    has_uppercase = re.search(r'[A-Z]', password)
    has_lowercase = re.search(r'[a-z]', password)
    has_digit = re.search(r'\d', password)
    has_specialchar = re.search(r'[!@#$%^&*()-_+=]', password)
    counter = 0
    if len(password) > 8:
        counter += 1
    if has_uppercase:
        counter += 1
    if has_lowercase:
        counter += 1
    if has_digit:
        counter += 1
    if has_specialchar:
        counter += 1
    return counter
password = input("Enter a password:")
strength = password_strength(password)
print("Password strength = ", strength/5*100,"%")