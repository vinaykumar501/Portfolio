import string
filename=open("vinay.txt","r")
dict={}
for line1 in filename:
	line1=line1.strip().lower()
	line1=line1.translate(line1.maketrans("","",string.punctuation))
	words=line1.split()
	for word in words:
		dict[word]=dict.get(word,0)+1
for word in sorted(dict.keys()):
	print(word,dict[word])
