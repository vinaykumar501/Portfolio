import random
def guess_the_number(a,b):
    num = random.randint(a,b)
    while True:
        guess=int(input(f"Guess a number between {a} and {b}: "))
        if guess < num:
            print("The number you guessed is too low.Please try again")
        elif guess > num:
            print("The number you guessed is too high.Please try again")
        else:
            print(f"You guessed the number {num} properly!")
            break
x,y=map(int,input("Enter the range of numbers:").split())
guess_the_number(x,y)