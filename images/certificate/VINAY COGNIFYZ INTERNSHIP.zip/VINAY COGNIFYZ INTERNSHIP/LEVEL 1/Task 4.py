def adder(a, b):
    return a + b
def subtracter(a, b):
    return a - b
def multiplier(a, b):
    return a * b
def divider(a, b):
    if b == 0:
        return "Error. Division by zero."
    else:
        return a / b
def modulo(a, b):
    if b == 0:
        return "Error. Division by zero."
    else:
        return a % b
x = float(input("Enter the first number: "))
y = float(input("Enter the second number: "))
operator = input("Enter an operator (+, -, *, /, %): ")
if operator == '/':
    print(f"{x} / {y} = {divider(x,y)}")
elif operator == '-':
    print(f"{x} - {y} = {subtracter(x,y)}")
elif operator == '+':
    print(f"{x} + {y} = {adder(x,y)}")
elif operator == '*':
    print(f"{x} * {y} = {multiplier(x,y)}")
elif operator == '%':
    print(f"{x} % {y} = {modulo(x,y)}")
else:
    print("Enter one of the following: -, +, *, /, %")