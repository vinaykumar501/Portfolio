def C_to_F(celsius):
    return ((celsius * 9/5) + 32)
def F_to_C(fahrenheit):
    return ((fahrenheit - 32) * 5/9)
temperature = float(input("Enter the temperature value: "))
unit_of_measurement = input("Enter unit of measurement(C for Celsius,F for Fahrenheit): ").upper()
if unit_of_measurement == 'F':
    converted_temperature = F_to_C(temperature)
    print(f"{temperature}°F = {converted_temperature}°C")
elif unit_of_measurement == 'C':
    converted_temperature = C_to_F(temperature)
    print(f"{temperature}°C = {converted_temperature}°F")
else:
    print("Enter 'C' for Celsius or 'F' for Fahrenheit.")
