import re
def email_validator(email):
    symbols = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if re.match(symbols, email):
        return True
    else:
        return False
email=input("Enter an email:")
check=email_validator(email)
print(f"Is {email} a valid email address?: {check}")