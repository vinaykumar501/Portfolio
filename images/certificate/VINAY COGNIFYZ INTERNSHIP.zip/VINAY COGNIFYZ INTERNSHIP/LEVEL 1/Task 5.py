def palindrome_tester(text):
    reverse_text=text[::-1]
    print(f"The reverse of the word {text} is {reverse_text}")
    if reverse_text==text:
        print("It is a palindrome")
    else:
        print("It's not a palindrome")
text=input("Enter string:")
palindrome_tester(text)