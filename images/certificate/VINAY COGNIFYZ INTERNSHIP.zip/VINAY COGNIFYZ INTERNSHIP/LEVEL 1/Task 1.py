def reverse_a_string(string):
  return string[::-1]
string=input("Enter a string to reverse: ")
reversed_text = reverse_a_string(string)
print("The reversed string is:",reversed_text)

